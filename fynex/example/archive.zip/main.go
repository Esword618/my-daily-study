package main

import (
	"image"
	"image/draw"
	"math/rand"
	"os"
	"strconv"
	"time"

	"fyne.io/fyne/v2"
	"fyne.io/fyne/v2/app"
	"fyne.io/fyne/v2/canvas"
	"fyne.io/fyne/v2/container"
	"fyne.io/fyne/v2/dialog"
	"fyne.io/fyne/v2/widget"
	"github.com/ncruces/zenity"
)

func main() {
	a := app.NewWithID("OCR tesseract")
	a.Settings().SetTheme(&myTheme{})
	win := a.NewWindow("demo")
	entry1 := widget.NewEntry()
	msg := widget.NewLabel("")
	img := NewClickImage().Do(func(b *ClickImage) {
		b.OnTapped = func(ci *ClickImage) {
			imgpath, _ := zenity.SelectFile(
				zenity.FileFilters{
					{"Image files", []string{"*.png", "*.jpeg", "*.jpg"}},
				},
				zenity.Title("Please choose an image"),
			)
			if imgpath == "" {
				return
			}
			b.Img.File = imgpath
			img, _ := os.Open(imgpath)
			b.Img.Image, _ = decodeImage(img)
			b.Img.Refresh()
			b.PlaceHolder.Hide()
		}
	})
	img.Img.FillMode = canvas.ImageFillContain

	n := 3

	empty := 0
	lbl1 := widget.NewLabel("")
	c1 := container.NewGridWithColumns(3)
	pieces := make([]fyne.CanvasObject, 9)
	times := 0
	btn1 := widget.NewButton("dooooo", func() {
		if img.Img.Image == nil {
			return
		}
		rgb1 := ImageToRGBA(img.Img.Image)
		w := rgb1.Rect.Dx() / n
		h := rgb1.Rect.Dy() / n
		n0 := 0
		for i := 0; i < n; i++ {
			for j := 0; j < n; j++ {
				v := NewClickImage()
				v.Img = canvas.NewImageFromImage(rgb1.SubImage(
					image.Rect(w*j, h*i, w*(j+1), h*(i+1))))
				v.Img.FillMode = canvas.ImageFillContain
				v.Data = n0
				v.Data0 = n0
				v.OnTapped = func(ci *ClickImage) {
					if CanMove(empty, v.Data) {
						tmp := empty
						c1.Objects[empty] = v
						empty = v.Data
						c1.Objects[empty] = lbl1
						v.Data = tmp
						c1.Refresh()
						times++
						entry1.SetText(strconv.Itoa(times))
					}
					if _, ok := c1.Objects[0].(*widget.Label); !ok {
						return
					}
					for i := 1; i < 9; i++ {
						obj := c1.Objects[i]
						if obj.(*ClickImage).Data !=
							obj.(*ClickImage).Data0 {
							return
						}
					}
					dialog.ShowInformation("Result", "Good Job", win)
				}
				pieces[n0] = v
				// c1.Add(v)
				n0++
			}
		}
		c1.Objects = pieces
		objs := shuffleObjs(pieces[1:])
		for i := 0; i < len(objs); i++ {
			objs[i].(*ClickImage).Data = i + 1
			c1.Objects[i+1] = objs[i]
		}
		c1.Objects[0] = lbl1
		empty = 0
		times = 0
		c1.Refresh()
	})
	btnRefresh := widget.NewButton("Refresh", func() {
		btn1.OnTapped()
	})
	top := container.NewHBox(entry1, btn1, btnRefresh)
	split := container.NewHSplit(img, c1)

	win.SetMaster()
	win.SetContent(container.NewBorder(top, msg, nil, nil, split))
	win.Resize(fyne.NewSize(800, 700))
	win.ShowAndRun()
}
func ImageToRGBA(src image.Image) *image.RGBA {
	bounds := src.Bounds()
	dst := image.NewRGBA(bounds)
	draw.Draw(dst, bounds, src, bounds.Min, draw.Src)
	return dst
}
func CanMove(empty, cur int) bool {
	var ints []int
	if empty == 0 {
		ints = []int{empty + 1, empty + 3}
	}

	if empty == 1 {
		ints = []int{empty + 1, empty + 3, empty - 1}
	}

	if empty == 2 {
		ints = []int{empty - 1, empty + 3}
	}

	if empty == 3 {
		ints = []int{empty + 1, empty + 3, empty - 3}
	}

	if empty == 4 {
		ints = []int{empty + 1, empty + 3, empty - 1, empty - 3}
	}
	if empty == 5 {
		ints = []int{empty - 1, empty + 3, empty - 3}
	}

	if empty == 6 {
		ints = []int{empty + 1, empty - 3}
	}
	if empty == 7 {
		ints = []int{empty + 1, empty - 3, empty - 1}
	}
	if empty == 8 {
		ints = []int{empty - 1, empty - 3}
	}
	for i := 0; i < len(ints); i++ {
		if ints[i] == cur {
			return true
		}
	}
	return false
}

func shuffleObjs(nums []fyne.CanvasObject) (snums []fyne.CanvasObject) {
	rand.Seed(time.Now().UTC().UnixNano())
	snums = append(snums, nums...)
	aliceRng := rand.New(rand.NewSource(time.Now().Unix()))
	aliceRng.Shuffle(
		len(snums),
		func(i, j int) {
			snums[i], snums[j] = snums[j], snums[i]
		})
	return
}

func shuffleArr(nums []int) (snums []int) {
	rand.Seed(time.Now().UTC().UnixNano())
	snums = append(snums, nums...)
	aliceRng := rand.New(rand.NewSource(time.Now().Unix()))
	aliceRng.Shuffle(
		len(snums),
		func(i, j int) {
			snums[i], snums[j] = snums[j], snums[i]
		})
	return
}
