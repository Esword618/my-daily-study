package main

// 两个数组的交集
// https://www.csdn.net/tags/MtTaEg1sNTYwNjY5LWJsb2cO0O0O.html
func SectionWithTwoArray(num1, num2 []int) []int{
	set := make(map[int]struct{}, 0)
	var res []int
	for _, v := range num1 {
		if _, ok := set[v]; !ok {
			// 去重
			set[v] = struct{}{}
		}
	}
	for _, v := range num2 {
		if _, ok := set[v]; ok {
			res = append(res, v)
			// 将此v删掉，避免结果中出现重复数据
			delete(set, v)
		}
	}
	return res
}