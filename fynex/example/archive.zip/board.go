//go:generate fyne bundle -o bundled-board.go board
//go:generate fyne bundle -o bundled-pieces.go pieces

package main

import (
	"fyne.io/fyne/v2"
	"fyne.io/fyne/v2/theme"
	"fyne.io/fyne/v2/widget"
)

type boardContainer struct {
	widget.BaseWidget

	objects []fyne.CanvasObject
	tapped  func()
}

func newBoardContainer(cells []fyne.CanvasObject, tap func()) *boardContainer {
	c := &boardContainer{objects: cells, tapped: tap}
	c.ExtendBaseWidget(c)
	return c
}

func (b *boardContainer) CreateRenderer() fyne.WidgetRenderer {
	return &boardRenderer{b: b, objects: b.objects}
}

func (b *boardContainer) Tapped(_ *fyne.PointEvent) {
	if b.tapped != nil {
		b.tapped()
	} else {
		fyne.LogError("no tapped event defined", nil)
	}
}
func (b *boardContainer) Add(o fyne.CanvasObject) {
	b.objects = append(b.objects, o)
}
func (b *boardContainer) Adds(objs ...fyne.CanvasObject) {
	b.objects = append(b.objects, objs...)
}

type boardRenderer struct {
	b       *boardContainer
	objects []fyne.CanvasObject
}

func (b *boardRenderer) Destroy() {
}

var n = 3

func (b *boardRenderer) Layout(s fyne.Size) {
	// if b.b.Layout == nil {
	// 	return
	// }
	// b.b.Layout(s)
	b.objects = b.b.objects
	if len(b.objects) < n*n {
		return
	}
	w:=s.Width/3
	h:=s.Height/3
	cellSize := fyne.NewSize(w,h)
	i := 0
	for y := 0; y < n; y++ {
		for x := 0; x < n; x++ {
			b.objects[i].Resize(cellSize)
			b.objects[i].Move(fyne.NewPos(
				2+float32(x)*w,2+ float32(y)*h))

			i++
		}
	}
}

func (b *boardRenderer) MinSize() fyne.Size {
	edge := theme.IconInlineSize() * 8
	return fyne.NewSize(edge, edge)
}

func (b *boardRenderer) Objects() []fyne.CanvasObject {
	return b.objects
}

func (b *boardRenderer) Refresh() {
}

func cellSize1(s fyne.Size) float32 {
	smallEdge := s.Width
	if s.Height < s.Width {
		smallEdge = s.Height
	}

	return smallEdge / 8
}
